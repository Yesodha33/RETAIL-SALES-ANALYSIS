# 🛍️ Retail Sales Analysis

## 📌 Project Overview
This project focuses on analyzing retail sales data to understand sales performance, customer purchasing behavior, product performance, and inventory management.

The project follows an end-to-end data analytics workflow using Excel, MySQL, Python, and Power BI to transform raw data into meaningful business insights.

## 🎯 Project Objectives
- Analyze sales trends and revenue performance.
- Identify top-performing products and categories.
- Understand customer purchasing behavior.
- Perform customer segmentation using RFM analysis.
- Analyze store performance and inventory levels.
- Build interactive dashboards for business reporting.

## 🛠️ Tools & Technologies
- **Excel:** Data preparation and cleaning
- **MySQL:** Database design and SQL analysis
- **Python:** Exploratory Data Analysis (EDA)
- **Pandas:** Data manipulation and analysis
- **Matplotlib & Seaborn:** Data visualization
- **Power BI:** Interactive dashboards and business reporting

## 🔄 Project Workflow

### Phase 1: Excel — Data Preparation
Prepared and reviewed the retail dataset for further analysis.

### Phase 2: MySQL — Database & SQL Analysis
- Designed a relational database.
- Worked with primary keys and foreign keys.
- Used SQL queries to analyze retail sales data.
- Connected relevant tables for analysis.

### Phase 3: Python — Exploratory Data Analysis
- Explored and analyzed data using Pandas.
- Performed data cleaning and exploratory analysis.
- Created RFM metrics:
  - **Recency:** How recently a customer purchased.
  - **Frequency:** How often a customer purchased.
  - **Monetary:** How much a customer spent.
- Performed customer segmentation.

### Phase 4: Power BI — Dashboard Development
- Connected Power BI to the SQL database.
- Created relationships between tables.
- Developed interactive sales and customer analysis reports.
- Used KPI cards, charts, and slicers.
- Analyzed product performance and inventory levels.


## 📊 Key Analysis Areas
- Sales performance and trends
- Total sales and orders
- Top-performing products
- Customer purchase analysis
- RFM customer segmentation
- Store performance
- Order status analysis
- Low-stock inventory monitoring

## 💡 Business Benefits
- Supports data-driven decision-making.
- Helps identify customer purchasing patterns.
- Provides visibility into product and sales performance.
- Supports inventory monitoring.
- Presents key business metrics through interactive dashboards.

## 📁 Project Files
- `EXCEL WORKING FILE.xlsx` — Excel project data
- `SQL Retail Sales — SQL scripts
- `PythonFile.ipynb` — Python analysis notebook
-  `Retail Sales PowerBI.pbix` — Power BI report
- `Dataset` — CSV files
- `RETAIL SALES ANALYSIS PROJECT REPORT-R.YESODHA.docx` — Project report

🎓 Project Done By
Student Name: R.Yesodha
Institute: Vinsup Skill Academy
Project Title: Retail Sales Analysis

## 🏁 Conclusion
This project provided hands-on experience in the end-to-end data analytics process, including data preparation, SQL querying, Python-based analysis, customer segmentation, and Power BI dashboard development.

It demonstrates the application of multiple analytics tools to explore retail data and present information that can support business decisions.
